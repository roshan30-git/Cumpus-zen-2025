import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const preferences = await sql`
      SELECT * FROM users_preferences 
      WHERE user_id = ${session.user.id}
      ORDER BY created_at DESC 
      LIMIT 1
    `;

    if (preferences.length === 0) {
      // Return default preferences if none exist
      return Response.json({
        notification_channel: 'push',
        categories: ['assignments', 'exams', 'clubs', 'social', 'announcements'],
        quiet_hours_start: '22:00',
        quiet_hours_end: '07:00',
        onboarding_completed: false
      });
    }

    return Response.json(preferences[0]);
  } catch (error) {
    console.error('Error fetching user preferences:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { 
      notification_channel, 
      telegram_username, 
      slack_username, 
      categories, 
      quiet_hours_start, 
      quiet_hours_end,
      onboarding_completed 
    } = body;

    // Check if preferences already exist
    const existing = await sql`
      SELECT id FROM users_preferences WHERE user_id = ${session.user.id}
    `;

    if (existing.length > 0) {
      // Update existing preferences
      const updated = await sql`
        UPDATE users_preferences 
        SET 
          notification_channel = COALESCE(${notification_channel}, notification_channel),
          telegram_username = COALESCE(${telegram_username}, telegram_username),
          slack_username = COALESCE(${slack_username}, slack_username),
          categories = COALESCE(${JSON.stringify(categories)}, categories),
          quiet_hours_start = COALESCE(${quiet_hours_start}, quiet_hours_start),
          quiet_hours_end = COALESCE(${quiet_hours_end}, quiet_hours_end),
          onboarding_completed = COALESCE(${onboarding_completed}, onboarding_completed),
          updated_at = NOW()
        WHERE user_id = ${session.user.id}
        RETURNING *
      `;
      return Response.json(updated[0]);
    } else {
      // Create new preferences
      const created = await sql`
        INSERT INTO users_preferences 
        (user_id, notification_channel, telegram_username, slack_username, categories, quiet_hours_start, quiet_hours_end, onboarding_completed)
        VALUES (${session.user.id}, ${notification_channel || 'push'}, ${telegram_username}, ${slack_username}, ${JSON.stringify(categories || ['assignments', 'exams', 'clubs', 'social', 'announcements'])}, ${quiet_hours_start || '22:00'}, ${quiet_hours_end || '07:00'}, ${onboarding_completed || false})
        RETURNING *
      `;
      return Response.json(created[0]);
    }
  } catch (error) {
    console.error('Error updating user preferences:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}