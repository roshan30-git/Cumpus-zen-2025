import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');
    const completed = url.searchParams.get('completed');
    const date = url.searchParams.get('date'); // YYYY-MM-DD format
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const offset = (page - 1) * limit;

    let query = `
      SELECT * FROM user_events 
      WHERE user_id = $1
    `;
    const params = [session.user.id];

    if (category && category !== 'all') {
      query += ` AND category = $${params.length + 1}`;
      params.push(category);
    }

    if (search) {
      query += ` AND (LOWER(title) LIKE LOWER($${params.length + 1}) OR LOWER(description) LIKE LOWER($${params.length + 2}))`;
      params.push(`%${search}%`);
      params.push(`%${search}%`);
    }

    if (completed !== null && completed !== undefined) {
      query += ` AND is_completed = $${params.length + 1}`;
      params.push(completed === 'true');
    }

    if (date) {
      query += ` AND DATE(due_date) = $${params.length + 1}`;
      params.push(date);
    }

    query += ` ORDER BY is_completed ASC, due_date ASC NULLS LAST, created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit);
    params.push(offset);

    const events = await sql(query, params);

    return Response.json(events);
  } catch (error) {
    console.error('Error fetching user events:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { 
      title, 
      description, 
      category, 
      due_date, 
      external_link, 
      source_type, 
      source_id 
    } = body;

    if (!title) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }

    const created = await sql`
      INSERT INTO user_events 
      (user_id, title, description, category, due_date, external_link, source_type, source_id)
      VALUES (${session.user.id}, ${title}, ${description}, ${category || 'assignments'}, ${due_date}, ${external_link}, ${source_type || 'manual'}, ${source_id})
      RETURNING *
    `;

    return Response.json(created[0]);
  } catch (error) {
    console.error('Error creating user event:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}