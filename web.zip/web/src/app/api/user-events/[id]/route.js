import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function PATCH(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { is_completed, title, description, category, due_date, external_link } = body;

    // Verify the event belongs to the user
    const event = await sql`
      SELECT id FROM user_events WHERE id = ${id} AND user_id = ${session.user.id}
    `;

    if (event.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    const updated = await sql`
      UPDATE user_events 
      SET 
        is_completed = COALESCE(${is_completed}, is_completed),
        title = COALESCE(${title}, title),
        description = COALESCE(${description}, description),
        category = COALESCE(${category}, category),
        due_date = COALESCE(${due_date}, due_date),
        external_link = COALESCE(${external_link}, external_link),
        updated_at = NOW()
      WHERE id = ${id} AND user_id = ${session.user.id}
      RETURNING *
    `;

    return Response.json(updated[0]);
  } catch (error) {
    console.error('Error updating user event:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = params;

    // Verify the event belongs to the user
    const event = await sql`
      SELECT id FROM user_events WHERE id = ${id} AND user_id = ${session.user.id}
    `;

    if (event.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    await sql`
      DELETE FROM user_events WHERE id = ${id} AND user_id = ${session.user.id}
    `;

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error deleting user event:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}