import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'daily'; // daily or weekly
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0];

    // Check if digest already exists for this date
    const existingDigest = await sql`
      SELECT * FROM digests 
      WHERE user_id = ${session.user.id} 
      AND digest_type = ${type} 
      AND digest_date = ${date}
      ORDER BY created_at DESC 
      LIMIT 1
    `;

    if (existingDigest.length > 0) {
      return Response.json(existingDigest[0]);
    }

    // Generate new digest
    const startDate = type === 'weekly' 
      ? new Date(Date.parse(date) - 6 * 24 * 60 * 60 * 1000).toISOString()
      : new Date(date).toISOString();
    
    const endDate = new Date(Date.parse(date) + 24 * 60 * 60 * 1000).toISOString();

    // Get user events for the period
    const events = await sql`
      SELECT * FROM user_events 
      WHERE user_id = ${session.user.id}
      AND (
        (due_date >= ${startDate} AND due_date < ${endDate}) OR
        (created_at >= ${startDate} AND created_at < ${endDate})
      )
      ORDER BY due_date ASC, created_at DESC
    `;

    // Get announcements for the period
    const announcements = await sql`
      SELECT * FROM announcements 
      WHERE (
        (due_date >= ${startDate} AND due_date < ${endDate}) OR
        (created_at >= ${startDate} AND created_at < ${endDate})
      )
      ORDER BY is_critical DESC, due_date ASC, created_at DESC
    `;

    // Generate digest content
    let content = generateDigestContent(events, announcements, type, date);

    // Save digest to database
    const savedDigest = await sql`
      INSERT INTO digests (user_id, digest_type, content, digest_date)
      VALUES (${session.user.id}, ${type}, ${content}, ${date})
      RETURNING *
    `;

    return Response.json(savedDigest[0]);
  } catch (error) {
    console.error('Error generating digest:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

function generateDigestContent(events, announcements, type, date) {
  const formattedDate = new Date(date).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  let content = `# ${type.charAt(0).toUpperCase() + type.slice(1)} Digest - ${formattedDate}\n\n`;

  // Upcoming deadlines
  const upcomingEvents = events.filter(e => e.due_date && new Date(e.due_date) > new Date());
  if (upcomingEvents.length > 0) {
    content += "## 📅 Upcoming Deadlines\n";
    upcomingEvents.forEach(event => {
      const dueDate = new Date(event.due_date).toLocaleDateString();
      const status = event.is_completed ? '✅' : '⏰';
      content += `${status} **${event.title}** - Due: ${dueDate}\n`;
      if (event.description) {
        content += `   ${event.description}\n`;
      }
    });
    content += "\n";
  }

  // Overdue items
  const overdueEvents = events.filter(e => e.due_date && new Date(e.due_date) < new Date() && !e.is_completed);
  if (overdueEvents.length > 0) {
    content += "## 🚨 Overdue Tasks\n";
    overdueEvents.forEach(event => {
      const dueDate = new Date(event.due_date).toLocaleDateString();
      content += `❗ **${event.title}** - Was due: ${dueDate}\n`;
      if (event.description) {
        content += `   ${event.description}\n`;
      }
    });
    content += "\n";
  }

  // Completed tasks
  const completedEvents = events.filter(e => e.is_completed);
  if (completedEvents.length > 0) {
    content += "## ✅ Completed Tasks\n";
    completedEvents.forEach(event => {
      content += `✓ ${event.title}\n`;
    });
    content += "\n";
  }

  // Important announcements
  const criticalAnnouncements = announcements.filter(a => a.is_critical);
  if (criticalAnnouncements.length > 0) {
    content += "## 🔔 Important Announcements\n";
    criticalAnnouncements.forEach(announcement => {
      content += `📢 **${announcement.title}**\n`;
      content += `   ${announcement.content.substring(0, 100)}...\n`;
      if (announcement.due_date) {
        const dueDate = new Date(announcement.due_date).toLocaleDateString();
        content += `   Due: ${dueDate}\n`;
      }
    });
    content += "\n";
  }

  // Regular announcements
  const regularAnnouncements = announcements.filter(a => !a.is_critical);
  if (regularAnnouncements.length > 0) {
    content += "## 📝 Recent Announcements\n";
    regularAnnouncements.forEach(announcement => {
      content += `• ${announcement.title}\n`;
    });
    content += "\n";
  }

  // Summary stats
  const totalTasks = events.length;
  const completedTasks = events.filter(e => e.is_completed).length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  content += "## 📊 Summary\n";
  content += `• Total tasks: ${totalTasks}\n`;
  content += `• Completed: ${completedTasks}\n`;
  content += `• Completion rate: ${completionRate}%\n`;
  content += `• Announcements: ${announcements.length}\n`;

  return content;
}