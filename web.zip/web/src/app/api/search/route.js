import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const category = searchParams.get('category');
    const startDate = searchParams.get('start_date');
    const endDate = searchParams.get('end_date');
    const limit = parseInt(searchParams.get('limit')) || 50;

    if (!query) {
      return Response.json({ events: [], announcements: [] });
    }

    // Search user events
    let eventsQuery = `
      SELECT *, 'event' as type FROM user_events 
      WHERE user_id = $1 AND (
        LOWER(title) LIKE LOWER($2) OR 
        LOWER(description) LIKE LOWER($3)
      )
    `;
    const eventsParams = [session.user.id, `%${query}%`, `%${query}%`];
    let paramIndex = 4;

    if (category && category !== 'all') {
      eventsQuery += ` AND category = $${paramIndex}`;
      eventsParams.push(category);
      paramIndex++;
    }

    if (startDate) {
      eventsQuery += ` AND due_date >= $${paramIndex}`;
      eventsParams.push(startDate);
      paramIndex++;
    }

    if (endDate) {
      eventsQuery += ` AND due_date <= $${paramIndex}`;
      eventsParams.push(endDate);
      paramIndex++;
    }

    eventsQuery += ` ORDER BY due_date DESC LIMIT $${paramIndex}`;
    eventsParams.push(limit);

    // Search announcements
    let announcementsQuery = `
      SELECT *, 'announcement' as type FROM announcements 
      WHERE (
        LOWER(title) LIKE LOWER($1) OR 
        LOWER(content) LIKE LOWER($2)
      )
    `;
    const announcementsParams = [`%${query}%`, `%${query}%`];
    let announceParamIndex = 3;

    if (category && category !== 'all') {
      announcementsQuery += ` AND category = $${announceParamIndex}`;
      announcementsParams.push(category);
      announceParamIndex++;
    }

    if (startDate) {
      announcementsQuery += ` AND created_at >= $${announceParamIndex}`;
      announcementsParams.push(startDate);
      announceParamIndex++;
    }

    if (endDate) {
      announcementsQuery += ` AND created_at <= $${announceParamIndex}`;
      announcementsParams.push(endDate);
      announceParamIndex++;
    }

    announcementsQuery += ` ORDER BY created_at DESC LIMIT $${announceParamIndex}`;
    announcementsParams.push(limit);

    const [events, announcements] = await Promise.all([
      sql(eventsQuery, eventsParams),
      sql(announcementsQuery, announcementsParams)
    ]);

    // Group results by category
    const results = {
      assignments: [],
      exams: [],
      clubs: [],
      social: [],
      announcements: []
    };

    [...events, ...announcements].forEach(item => {
      if (results[item.category]) {
        results[item.category].push(item);
      }
    });

    return Response.json(results);
  } catch (error) {
    console.error('Error searching:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}