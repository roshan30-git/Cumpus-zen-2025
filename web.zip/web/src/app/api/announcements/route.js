import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const offset = (page - 1) * limit;

    let query = `
      SELECT * FROM announcements 
      WHERE 1=1
    `;
    const params = [];

    if (category && category !== 'all') {
      query += ` AND category = $${params.length + 1}`;
      params.push(category);
    }

    if (search) {
      query += ` AND (LOWER(title) LIKE LOWER($${params.length + 1}) OR LOWER(content) LIKE LOWER($${params.length + 2}))`;
      params.push(`%${search}%`);
      params.push(`%${search}%`);
    }

    query += ` ORDER BY is_pinned DESC, created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit);
    params.push(offset);

    const announcements = await sql(query, params);

    return Response.json(announcements);
  } catch (error) {
    console.error('Error fetching announcements:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { 
      title, 
      content, 
      category, 
      is_pinned, 
      is_critical, 
      due_date, 
      external_link, 
      attachment_url 
    } = body;

    if (!title || !content) {
      return Response.json({ error: "Title and content are required" }, { status: 400 });
    }

    const user = await sql`SELECT name, email FROM auth_users WHERE id = ${session.user.id}`;
    const authorName = user[0]?.name || user[0]?.email || 'Unknown';

    const created = await sql`
      INSERT INTO announcements 
      (title, content, category, is_pinned, is_critical, due_date, external_link, attachment_url, author_id, author_name)
      VALUES (${title}, ${content}, ${category || 'announcements'}, ${is_pinned || false}, ${is_critical || false}, ${due_date}, ${external_link}, ${attachment_url}, ${session.user.id}, ${authorName})
      RETURNING *
    `;

    return Response.json(created[0]);
  } catch (error) {
    console.error('Error creating announcement:', error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}